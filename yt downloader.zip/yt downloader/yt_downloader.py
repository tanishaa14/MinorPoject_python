from tkinter import *
from PIL import ImageTk, Image #image library (download pip install pillow)
from tkinter import messagebox
from pytube import YouTube


def yt_download():
    yt_link = url_input.get()
    link = YouTube(yt_link)
    video  = link.streams.get_highest_resolution()
    video.download()
    messagebox.showinfo("yooo","Video Downloaded Sucessfully")



root = Tk()



#header 
root.title("G6 YTdownloader") #header title
root.iconbitmap("favicon.ico") #header icon

#control window size
    #root.minsize(900,720) 

root.geometry("700x500") #size of the window 

root.configure(background="#0F1323") #bg color



#desc_label

desc = Label(text="YouTube video downloader Minor Project",fg="white",bg="#0F1323")
desc.pack(pady=(30))
desc.config(font=(12))
#image 
img = Image.open("image.png") #open image
resized_image = img.resize((140,120))  # resize image
img = ImageTk.PhotoImage(resized_image) #insert image
img_label = Label(root,image=img) #add image in ui
img_label.pack(pady=(0,20)) #padding


#add text

text1 = Label(root, text="G6 downloader",fg="white",bg="#0F1323")
text1.pack(padx=(30))
text1.config(font=("verdana",24))


#input_field_label

url_label = Label(root, text="Enter video Url",fg="white", bg="#0F1323")
url_label.pack(pady=(30,10),padx=(0,200))
url_label.config(font=(14))

#input_field_url

url_input = Entry(root,width=50)
url_input.pack(ipady=4,pady=(0,10))


#button
butn = Button(root, text="Download", bg = "red", fg= "white",width=15,height=1, command=yt_download)
butn.pack(pady=(10,10))
butn.config(font=(21))


#label_end

end_label = Label(root,text="Free tool  help to download video from Youtube for free.",fg="red",bg="#0F1323")
end_label.pack(pady=(10))
end_label.config(font=(12))



























root.mainloop()